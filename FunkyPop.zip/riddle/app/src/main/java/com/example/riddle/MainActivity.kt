package com.example.riddle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.riddle.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    public val zagadki = arrayListOf<String>("Что это такое: синий, большой, с усами и полностью набит зайцами?",
        "Не ездок, а со шпорами,Не будильник, а всех будит.",
        "Она красива и мила, А имя ей от слова зола.",
        "Ношу их много лет, А счету им не знаю.",
        "Кто меня сделал, не сказывает. Кто меня не знает, принимает. А кто знает, на двор не пускает.",
        "Если б не было его, Не сказал бы ничего.",
        "Стоит толстуха - Деревянное брюхо, Железный поясок.",
        "Кругом вода, а с питьем беда. ",
        "Тридцать два молотят, один поворачивает.",
        "Зубов много, а ничего не ест.",
        "Я легкий как перышко, но долго меня не удержишь.",
        "Есть всегда у людей Есть всегда у кораблей.",
        "Не ездок, а со шпорами, не сторож, а всех будит",
        "В этот месяц таит все, в этот месяц снег идёт, в этот месяц все теплей, в этот месяц женский день.",
        "Вертится, стрекочет, Весь день хлопочет.")


    public val otv = arrayListOf<String>("Троллейбус","Подушка","Золушка","Волосы","Фальшивая монета","Язык","Бочка","Море","Зубы и язык","Расческа","Вдох","Нос","петух","март","Сорока")

    fun btnGetZagadka(view: View) {
        binding.txtTextZagadki.text=zagadki.random()
        binding.btnZaga.isEnabled=false
        binding.btnOtvet.isEnabled=true

    }



}